public class TrafficController {

    public void enterLeft() {}
    public void enterRight() {}
    public void leaveLeft() {}
    public void leaveRight() {}

}